from pathlib import Path
import pandas as pd
from PIL import Image
from datasets import (
    load_dataset,
    Dataset as HuggingFaceDataset,
)
from typing import Optional, Any, Mapping

from src.task.base_dataset import BaseDataset, DatasetOutput


class OCRBench(BaseDataset):
    def __init__(self, question_path, image_dir_path=None, context=None):
        question_path = Path(question_path)

        self.image_dir_path = Path(image_dir_path)

        self.context = context or "You are a helpful assistant"

        if not question_path.is_file():
            print(f"Error: JSON file not found at '{question_path}'")

        try:
            df = pd.read_json(
                question_path, orient="records", dtype=False
            )  # dtype=False prevents auto int/float conversion

            print(f"Successfully loaded {len(df)} records from {question_path}")

            # Optional: Convert specific columns if needed after loading

            self.df = self._clean_df(df)

        except Exception as e:
            print(f"Error reading JSON file '{question_path}': {e}")

            exit(0)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        data = self.df.iloc[index]

        image_path = self.image_dir_path / data["image_path"]

        # print(image_path)

        image = Image.open(image_path)

        return DatasetOutput(
            context=self.context,
            question=data["question"],
            image=image,
            gt=data["answers"],
            metadata=data[["dataset_name", "type", "id"]].to_dict(),
        )

    def _clean_df(self, df):
        to_str = ["dataset_name", "image_path", "type", "question"]

        for name in to_str:
            df[name] = df[name].astype("string")

        return df


class RedTeamingVLMDataset(BaseDataset):
    """
    Loads specified percentages of MMInstruction/RedTeamingVLM configurations.
    Includes default percentages that can be overridden.
    """

    def __init__(
        self,
        context: Optional[str] = None,
        config_percentages: Optional[Mapping[str, float]] = None,
        shuffle_seed: Optional[int] = 42,
    ) -> None:
        if load_dataset is None or Image is None or HuggingFaceDataset is None:
            raise ImportError("Required libraries ('datasets', 'Pillow') not found.")

        # super().__init__(...) # Call BaseDataset's init if necessary

        self.context = context or "You are a helpful assistant"
        self.data_items: list[dict[str, Any]] = []
        self._shuffle_seed = shuffle_seed
        dataset_id = "MMInstruction/RedTeamingVLM"

        DEFAULT_CONFIG_PERCENTAGES: dict[str, float] = {
            "misleading": 0.8,
            "captcha": 0.5,
            "jailbreak": 0.5,
            "face": 0.1,
            "celeb": 0.5,
            "racial": 0.5,
            "visual_misleading_wrong": 0.25,
            "visual_misleading_correct": 0.25,
        }

        final_percentages = DEFAULT_CONFIG_PERCENTAGES.copy()
        if config_percentages is not None:
            final_percentages.update(config_percentages)

        available_configs = [  # Using fixed list as per user modification
            "misleading",
            "captcha",
            "jailbreak",
            "face",
            "celeb",
            "politics",
            "racial",
            "visual_misleading_wrong",
            "visual_misleading_correct",
        ]

        for config_name in available_configs:
            try:
                percentage = final_percentages.get(
                    config_name, 1.0
                )  # Default to 100% if not specified

                if not (0.0 <= percentage <= 1.0):
                    percentage = 1.0
                if percentage == 0.0:
                    continue  # Skip this config

                # print(f"Loading config: {config_name} (Target: {percentage*100:.1f}%)") # Optional print
                dataset_dict = load_dataset(
                    dataset_id, name=config_name, trust_remote_code=True
                )

                split_name = "test"
                if split_name not in dataset_dict:
                    available_splits = list(dataset_dict.keys())
                    if not available_splits:
                        continue  # Skip if no splits
                    split_name = available_splits[0]

                config_data: HuggingFaceDataset = dataset_dict[split_name]
                original_size = len(config_data)
                num_to_keep = int(original_size * percentage)
                num_to_keep = max(
                    0, min(num_to_keep, original_size)
                )  # Clamp between 0 and original_size

                if original_size == 0 or num_to_keep == 0:
                    continue  # Skip if empty or 0 items needed

                if num_to_keep >= original_size:
                    subset_data = config_data
                else:
                    shuffled_data = config_data.shuffle(seed=self._shuffle_seed)
                    subset_data = shuffled_data.select(range(num_to_keep))

                # Process items from the subset
                for i, item in enumerate(subset_data):
                    required_fields = ["questions", "answers", "img"]
                    if not all(
                        field in item and item[field] is not None
                        for field in required_fields
                    ):
                        # print(f"Warning: Skipping item in {config_name} due to missing/None required fields.") # Optional warning
                        continue

                    image = item["img"]
                    question = item["questions"]
                    ground_truth = item["answers"]

                    if not isinstance(question, str):
                        continue
                    if Image is not None and not isinstance(image, Image.Image):
                        image = None  # Allow processing without image if PIL fails

                    self.data_items.append(
                        {
                            "question": question,
                            "image": image,
                            "gt": ground_truth,
                            "metadata": {
                                "dataset_name": "RedTeamingVLM",
                                "config": config_name,
                                "split": split_name,
                                "percentage_loaded": percentage,
                                "refused_to_answer": item.get(
                                    "refused_to_answer", None
                                ),
                                "original_config_index": item.get(
                                    "__index_level_0__", i
                                ),
                            },
                        }
                    )

            except Exception as e:
                print(f"Error processing config '{config_name}': {e}")

        print(f"Finished loading. Total items: {len(self.data_items)}")

    def __len__(self) -> int:
        return len(self.data_items)

    def __getitem__(self, index) -> DatasetOutput:
        if not 0 <= index < len(self.data_items):
            raise IndexError(
                f"Index {index} out of range for dataset length {len(self.data_items)}"
            )
        item_data = self.data_items[index]
        return DatasetOutput(
            context=self.context,
            question=item_data["question"],
            image=item_data["image"],
            gt=item_data["gt"],
            metadata=item_data["metadata"],
        )
