import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PIL import Image
from torch.utils.data import Dataset


@dataclass
class DatasetOutput:
    context: str
    question: str
    image: Optional[Image.Image] = None
    gt: Optional[str | list[str]] = None
    metadata: Optional[dict] = None


class BaseDataset(Dataset):
    def __init__(
        self, question_path: str, image_dir_path: str = None, context: str = None
    ) -> None:
        # Loads the context, the questions and image dir

        self.question_path = question_path  # direct path to json

        if image_dir_path is not None:
            self.image_dir_path = Path(image_dir_path)

        else:
            self.image_dir_path = Path(question_path).parent / Path("images")

        self.context = context or "You are a helpful assistant"

        with open(question_path, mode="r", encoding="utf-8") as file:
            self.question_data: dict[list[dict]] = json.load(file)

        if "questions" in self.question_data:
            self.questions: list[dict] = self.question_data["questions"]

    def __len__(self) -> int:
        return len(self.questions)

    def __getitem__(self, index) -> DatasetOutput:
        question_data = self.questions[index]

        image = None

        if question_data["image"] != 0:
            image_path = self.image_dir_path / question_data["image"]

            image = Image.open(image_path)

        return DatasetOutput(
            context=self.context,
            question=question_data["question"],
            image=image,
            gt=question_data["answers"],
        )

    @staticmethod
    def _collate_fn(x):
        return list(x)
