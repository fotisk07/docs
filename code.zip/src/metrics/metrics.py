from abc import ABC, abstractmethod
from typing import Union

from src.metrics.match import CorrectnessStrategy, LLMJailbreakSeverityScore


class BaseMetric(ABC):
    def __init__(self):
        self.reset()

    @abstractmethod
    def update(
        self,
        prediction: str | list[str],
        targets: Union[str, list[str]],
        raw: bool = False,
        question : str = None,
    ) -> None:
        pass

    @abstractmethod
    def calculate(self) -> dict[str, float]:
        pass

    @abstractmethod
    def reset(self) -> None:
        pass


class AccuracyMetric(BaseMetric):
    def __init__(self, correctness_strategy: CorrectnessStrategy):
        super().__init__()

        self.correctness_strategy = correctness_strategy
        self.correct_count = 0
        self.total_count = 0

    def update(
        self, prediction: str, targets: Union[str, list[str]], raw: bool = False, question=None
    ):
        if isinstance(prediction, list):
            for pred in prediction:
                self.update(pred, targets, raw=raw)

            return

        assert isinstance(prediction, str), f"Prediction must be str not {prediction}"

        correct = False

        if self.correctness_strategy.is_correct(prediction, targets):
            self.correct_count += 1

            correct = True

        self.total_count += 1

        if raw:
            return correct

    def calculate(self):
        res = self.correct_count / self.total_count if self.total_count > 0 else 0.0

        return dict(accuracy=res)

    def reset(self):
        self.correct_count = 0
        self.total_count = 0


class PlaceHolderSeverityScore(BaseMetric):
    def __init__(self, correctness_strategy : LLMJailbreakSeverityScore):
        assert isinstance(correctness_strategy, LLMJailbreakSeverityScore)
        self.correctness_strategy = correctness_strategy

    def update(
        self, prediction: str, targets: Union[str, list[str]], raw: bool = False, question:str=None
    ):
        if isinstance(prediction, list):
            for pred in prediction:
                self.update(pred, targets, raw=raw)

            return

        assert isinstance(prediction, str), f"Prediction must be str not {prediction}"

        safety_rating = self.correctness_strategy.is_correct(target=question, prediction=prediction)

        if raw:
            return safety_rating

    def calculate(self):
        return {}

    def reset(self):
        pass