#!/bin/bash

# Optional: set your logging root
EXP_NAME="FigStep/Baseline"

echo "Running Baseline on Figstep"

# Corrected command: Arguments follow the script name on the same logical line,
# using backslashes (\) for readability across multiple physical lines.
uv run run.py \
    device=cuda \
    task=Figstep \
    max_new_tokens=1000 \
    exp_name=${EXP_NAME} \
    matches=True \
    task.deduplication=True \
    metrics=jailbreak