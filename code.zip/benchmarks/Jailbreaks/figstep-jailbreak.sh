#!/bin/bash
set -euo pipefail

# Optional: set your logging root
EXP_NAME="FigStep/BaseStrategy"

echo "Running Figstep base"

uv run run.py \
    device=cuda \
    task=Figstep \
    task.deduplication=True \
    task.prompt_type=FigStep \
    max_new_tokens=1000 \
    exp_name=${EXP_NAME} \
    matches=True \
    temperature=0.8 \
    metrics=jailbreak

# Optional: set your logging root
EXP_NAME="FigStep/ProStrategy"

echo "Running Figstep pro"

uv run run.py \
    device=cuda \
    task=Figstep \
    task.deduplication=True \
    task.prompt_type=FigStep-Pro \
    max_new_tokens=1000 \
    exp_name=${EXP_NAME} \
    matches=True \
    temperature=0.8 \
    metrics=jailbreak