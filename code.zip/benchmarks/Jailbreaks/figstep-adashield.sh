#!/bin/bash
set -euo pipefail

# Optional: set your logging root
EXP_NAME="FigStep/BaseStrategy+adashield"

echo "#####################################"
echo "Running Figstep base with adashield"
echo "#####################################"

uv run run.py \
    device=cuda \
    task=Figstep+adashield \
    task.OtherClass.deduplication=True \
    task.OtherClass.prompt_type=FigStep \
    max_new_tokens=1000 \
    exp_name=${EXP_NAME} \
    matches=True \
    temperature=0.8 \
    metrics=jailbreak

# Optional: set your logging root
EXP_NAME="FigStep/ProStrategy+adashield"

echo "#####################################"
echo "Running Figstep pro with adashield"
echo "#####################################"

uv run run.py \
    device=cuda \
    task=Figstep+adashield \
    task.OtherClass.deduplication=True \
    task.OtherClass.prompt_type=FigStep \
    max_new_tokens=1000 \
    exp_name=${EXP_NAME} \
    matches=True \
    temperature=0.8 \
    metrics=jailbreak