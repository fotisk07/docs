import json
import logging
import os
import shutil
from dataclasses import asdict, dataclass
from pprint import pprint
from time import time
from typing import Optional

import hydra
from hydra.utils import instantiate
from omegaconf import DictConfig, OmegaConf

from src.metrics.metrics import BaseMetric
from src.solver.phi import Phi3
from src.task.base_dataset import BaseDataset

log = logging.getLogger(__name__)


######################## Simple Inference ##############################


@dataclass
class solver_params:
    max_new_tokens: int
    do_sample: bool
    temperature: float
    num_beams: int
    num_return_sequences: int
    top_k: int = None
    top_p: float = None
    stream: bool = False


@dataclass
class inf_config:
    solver_params: solver_params
    matches: bool = False
    filename: str = None
    save_every: int = 1


def load_existing_data(filename: str | None) -> dict:
    if filename is None:
        return {"Predicted answers": [], "matches": []}

    if os.path.exists(filename):
        shutil.copyfile(
            filename,
            os.path.join(
                hydra.core.hydra_config.HydraConfig.get().runtime.output_dir,
                "out.json",
            ),
        )  # copy the file to current hydra

        with open(filename, "r") as f:
            try:
                return json.load(f)

            except json.JSONDecodeError:
                print(f"Warning: {filename} is not valid JSON. Starting fresh.")

                return {"Predicted answers": [], "matches": []}

    return {"Predicted answers": [], "matches": [], "inf time": []}


def atomic_save(data, filename):
    tmp_filename = filename + ".tmp"

    with open(tmp_filename, "w") as f:
        json.dump(data, f, indent=2)

    os.replace(tmp_filename, filename)


def simple_inference(
    solver: Phi3,
    task: BaseDataset,
    config: inf_config,
    metric: Optional[BaseMetric] = None,
):
    results = load_existing_data(config.filename)

    index = len(results["Predicted answers"])

    config.filename = os.path.join(
        hydra.core.hydra_config.HydraConfig.get().runtime.output_dir,
        "out.json",
    )  # load data copies the file so we work on our folder

    print("Loaded model, starting inference")

    if index > 0:
        print(f"Continuing from index {index}")

    print(f"Saving results in {config.filename}...")

    for i in range(index, len(task)):
        sample = task[i]  # start from the index
        log.info(sample.question)
        t0 = time()
        output = solver.generate(sample, **asdict(config.solver_params))
        dt = time() - t0
        log.info(output)
        results["Predicted answers"].append(output)
        results["inf time"].append(dt)

        if metric is not None:  # if metric given
            is_match = metric.update(output, sample.gt, raw=config.matches, question=sample.question)
            if config.matches:  # if raw data required
                results["matches"].append(is_match)

        if i % config.save_every == 0:
            atomic_save(results, config.filename)

    # End of the loop save everything
    metric_res = metric.calculate() if metric else {}  # in case there is no metric
    pprint(metric_res)
    results["metrics"] = metric_res
    atomic_save(results, config.filename)


# ------------------------- Main function ---------------------------------

# Instantiates solver, task and optionally metric, and runs it


@hydra.main(config_path="configs", config_name="default.yaml", version_base=None)
def main(config: DictConfig):
    print("Configuration used :")
    print(OmegaConf.to_yaml(config))

    solver: Phi3 = instantiate(config.solver)
    task: BaseDataset = instantiate(config.task)
    try:  # in case there is no metric
        metric: BaseMetric = instantiate(config.metrics)
        log.info("Initialized metric")
    except Exception as e:
        log.info(f"No metric was initialised: {e}")
        metric = None


    # Optional dataclass usage for typehints later
    config = inf_config(
        solver_params(
            config.max_new_tokens,
            config.do_sample,
            config.temperature,
            config.num_beams,
            config.num_return_sequences,
            config.top_k,
            config.top_p,
            config.stream,
        ),
        config.matches,
        config.filename,
        config.save_every,
    )
    # Go brrr
    simple_inference(solver, task, config, metric)


if __name__ == "__main__":
    main()
